%% Description: Plot solar variables and pump flows inputs
%
% This script plots the solar variables and pump flows inputs of the 
% PVT hybrid solar panel. 
%
% Copyright 2023 Roxana Grigore, S. G. Gabriel, S. E. Popa, and I. V. Banu.

%% Setup
model = 'PVT_hybrid_solar_panel';

if ~strcmp(bdroot, model)
    load_system(model);
    set_param(0, 'CurrentSystem', model);
end

%% Generate Data for Figures

solar_irradiance_t = evalin('base', (get_param(...
    [model, '/Solar Inputs/Solar Irradiance'], 'rep_seq_t')));

solar_irradiance_y = evalin('base', (get_param(...
    [model, '/Solar Inputs/Solar Irradiance'], 'rep_seq_y')));

solar_inclination_t = evalin('base', (get_param(...
    [model, '/Solar Inputs/Solar Inclination'], 'rep_seq_t')));

solar_inclination_y = evalin('base', (get_param(...
    [model, '/Solar Inputs/Solar Inclination'], 'rep_seq_y')));


internal_flow_t = evalin('base', (get_param(...
    [model, '/Pump Flow Inputs/Internal Flow'], 'rep_seq_t')));

internal_flow_y = evalin('base', (get_param(...
    [model, '/Pump Flow Inputs/Internal Flow'], 'rep_seq_y')));

demand_t = evalin('base', (get_param(...
    [model, '/Pump Flow Inputs/Demand'], 'rep_seq_t')));

demand_y = evalin('base', (get_param(...
    [model, '/Pump Flow Inputs/Demand'], 'rep_seq_y')));

supply_t = evalin('base', (get_param(...
    [model, '/Pump Flow Inputs/Supply'], 'rep_seq_t')));

supply_y = evalin('base', (get_param(...
    [model, '/Pump Flow Inputs/Supply'], 'rep_seq_y')));

%% Create Figures

% Solar
if ~exist('figHandleSolarInputs', 'var') || ~isgraphics(figHandleSolarInputs, 'figure')
    figHandleSolarInputs = figure('Name','PVT_hybrid_solar_panel_Solar Inputs');
end

figure(figHandleSolarInputs);
clf(figHandleSolarInputs);
set(figHandleSolarInputs, 'Position', [90   250   430   430]);

subplot(2,1,1);
plot(solar_irradiance_t/3600, solar_irradiance_y, 'r', 'LineWidth', 1.5);
xlim([0, 24]);
title('Solar Irradiance');
xlabel('Time [h]');
ylabel('Irradiance [W/m^2]');
grid on
box on

subplot(2,1,2);
plot(solar_inclination_t/3600, solar_inclination_y, ...
    'Color', [0.9290, 0.6940, 0.1250]	, 'LineWidth', 1.5);
xlim([0, 24]);
title('Solar Inclination');
xlabel('Time [h]');
ylabel('Absolute Angle [rad]');
grid on
box on

%Pumps
if ~exist('figHandlePumpInputs', 'var') || ~isgraphics(figHandlePumpInputs, 'figure')
    figHandlePumpInputs = figure('Name','PVT_hybrid_solar_panel_Pumps Inputs');
end

figure(figHandlePumpInputs);
clf(figHandlePumpInputs);
set(figHandlePumpInputs, 'Position', [520  250   430   430]);

subplot(3,1,1);
plot(internal_flow_t/3600, internal_flow_y, 'c', 'LineWidth', 1.5);
xlim([0, 24]);
title('Internal Flow');
ylabel('Mass Flow Rate [kg/s]');
grid on
box on

subplot(3,1,2);
plot(demand_t/3600, demand_y, 'b', 'LineWidth', 1.5);
xlim([0, 24]);
title('Demand');
ylabel('Mass Flow Rate [kg/s]');
grid on
box on

subplot(3,1,3);
plot(supply_t/3600, supply_y, 'm', 'LineWidth', 1.5);
xlim([0, 24]);
title('Supply');
xlabel('Time [h]');
ylabel('Mass Flow Rate [kg/s]');
grid on
box on
