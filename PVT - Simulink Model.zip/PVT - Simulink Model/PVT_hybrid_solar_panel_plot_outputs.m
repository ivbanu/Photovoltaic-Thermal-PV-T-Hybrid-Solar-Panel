%% Description: Plot Temperatures, Power, and Volume of Tank Outputs

% This script plots the PV/T hybrid solar panel outputs: temperatures of
% the thermal masses, useful power (electrical and thermal), and tank volume.

% Copyright 2023 Roxana Grigore, S. G. Gabriel, S. E. Popa, and I. V. Banu.

%% Setup
model = 'PVT_hybrid_solar_panel';

if ~strcmp(bdroot, model)
    load_system(model);
    set_param(0, 'CurrentSystem', model);
end

%% Generate Data for Figure
if ~exist('out', 'var')
    out = sim(model);
end

tout = out.tout;

Tg_series = out.simlog_hybrid_solar_panel.Glass.T.series.values;
Tpv_series = out.simlog_hybrid_solar_panel.Solar_Cell.temperature.series.values;
Te_series = out.simlog_hybrid_solar_panel.Exchanger.T.series.values;
Tb_series = out.simlog_hybrid_solar_panel.Back.T.series.values;
Tw_series = out.simlog_hybrid_solar_panel.Tank.T_I.series.values;

Pow_elec_series = out.simlog_hybrid_solar_panel.Electrical_Resistive_Load.Voltage_Sensor.V.series.values .* ...
    out.simlog_hybrid_solar_panel.Electrical_Resistive_Load.Current_Sensor.I.series.values;

Pow_therm_series = out.simlog_hybrid_solar_panel.Sensor1.Mass_Energy_Flow_Rate_Sensor_TL.PHI.series.values ...
    - out.simlog_hybrid_solar_panel.Sensor1.Mass_Energy_Flow_Rate_Sensor_TL1.PHI.series.values;

Voltank_series = out.simlog_hybrid_solar_panel.Tank.volume.series.values;

%% Create Figure

% Temperatures
if ~exist('figHandleOutputs', 'var') || ~isgraphics(figHandleOutputs, 'figure')
    figHandleOutputs = figure('Name','PVT_hybrid_solar_panel_outputs');
end

figure(figHandleOutputs);
clf(figHandleOutputs);
set(figHandleOutputs, 'Position', [15,   60,   770,   480]);

% Temperatures
subplot(3,1,1);
plot(tout/3600, Tg_series, '--', 'Color', [1 0 0], 'LineWidth', 1.5);
xlim([0 70]);
hold on
plot(tout/3600, Tpv_series, ':', 'Color', [1 0.2 0], 'LineWidth', 1.5);
plot(tout/3600, Te_series, '-.', 'Color', [1 0.4 0], 'LineWidth', 1.5);
plot(tout/3600, Tb_series, '-', 'Color', [1 0.6 0], 'LineWidth', 1.5);
plot(tout/3600, Tw_series, '-', 'Color', [1 0.8 0], 'LineWidth', 1.5);
legend('Glass', 'PV Solar Cells', 'Exchanger', 'Back', 'Tank water');
title('Temperatures');
xlabel('Time [h]');
ylabel('[K]');
grid on
box on

% Power
subplot(3,1,2);
plot(tout/3600, Pow_elec_series,  'Color', [0, 0.1, 1]	, 'LineWidth', 1.5);
xlim([0 70]);
hold on
plot(tout/3600, Pow_therm_series, '-.',  'Color', [0, 0.6, 1]	, 'LineWidth', 1.5);
legend('Eletrical Power to Load', 'Thermal Power to Demanded Water')
title('Useful Power');
xlabel('Time [h]');
ylabel('[W]');
grid on
box on

% Volume
subplot(3,1,3);
plot(tout/3600, Voltank_series, 'Color', [0, 0.7, 0], 'LineWidth', 1.5);
xlim([0 70]);
ylim([0 0.25])
legend('Tank Volume')
title('Water Volume in the Tank');
xlabel('Time [h]');
ylabel('[m^3]');
grid on
box on